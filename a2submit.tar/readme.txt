Evan Switzer
0971076
Parallel A2

Everything works as indented for A2.
